'use babel';

import SwdcAtomView from '../lib/swdc-atom-view';

describe('SwdcAtomView', () => {
  it('has one valid test', () => {
    expect('life').toBe('easy');
  });
});
